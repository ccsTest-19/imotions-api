import {EventEmitter} from "events";
import {Socket} from "net";
import {openSocket} from "./ApiUtils";

export const connectEventForwardingApi = async (port = 8088) => {
    try {
        return new ReceiveFromImotions(await openSocket(port));
    } catch (e) {
        throw new Error(
            `Unable to connect to iMotions software, please check that it is running and that the Event Forwarding API is enabled on port ${port}`
        );
    }
};

/**
 * Receive study and sensor events from the iMotions software via the "Event Forwarding API".
 * After connecting the events are emitted as normal EventEmitter events with both their event source name and sample name (i.e. you can listen for either).
 */
export default class ReceiveFromImotions extends EventEmitter {
    private readonly socket: Socket;

    constructor(socket: Socket) {
        super();
        this.socket = socket;

        socket.on("data", rawData => {
            const withTrailingLinebreak = rawData.toString();
            const data = withTrailingLinebreak.substr(0, withTrailingLinebreak.length - 2).split(";");

            const eventSource = data[1];
            const sampleName = data[2];

            this.emit("*", data);
            this.emit(eventSource, data);
            this.emit(sampleName, data);
        });
    }

    close() {
        this.socket.end();
    }
}
