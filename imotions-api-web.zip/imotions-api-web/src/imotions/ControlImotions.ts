import {Socket} from "net";
import {openSocket, sanitize} from "./ApiUtils";

export const connectRemoteControlApi = async (port = 8087) => {
    try {
        return new ControlImotions(await openSocket(port));
    } catch (e) {
        throw new Error(
            `Unable to connect to iMotions software, please check that it is running and that the Remote Control API is enabled on port ${port}`
        );
    }
};

interface StatusResponse {
    study: string;
    respondent: string;
    stimulus: string;
    isBusy: boolean;
    statusText: string;
    progressText: string;
}

type UiOptions = "NormalPrompt" | "NoPromptIgnoreWarnings" | "NoPrompt";

type ImportOptions = "Create" | "Merge" | "Auto";

/**
 * Send commands to the iMotions software to control the running study and perform administrative tasks via the "Remote Control API".
 */
export class ControlImotions {
    private readonly socket: Socket;

    constructor(socket: Socket) {
        this.socket = socket;
    }

    private sendCommand(command: string, version = 1, args: string[] = []): Promise<string[]> {
        return new Promise((resolve, reject) => {
            const id = "" + Math.round(Math.random() * 1000000);

            const handleData = (rawData: Buffer) => {
                const withTrailingLinebreak = rawData.toString();
                const data = withTrailingLinebreak.substr(0, withTrailingLinebreak.length - 2).split(";");

                const incomingId = data[5];
                const status = data[6];
                const failReason = data[7];

                if (incomingId !== id) {
                    // This was a reply for a command sent by someone else, so ignore it.
                    return;
                }

                if (status === "0") {
                    this.close();
                    reject(new Error(`Error when executing remote control command: ${failReason}`));
                    return;
                }

                this.socket.off("data", handleData);
                resolve(data);
            };
            this.socket.on("data", handleData);

            const cmd = ["R", "" + version, id, command].concat(args).join(";") + "\r\n";
            this.socket.write(cmd);
        });
    }

    /**
     * Minimize the iMotions software window if it is not running a study.
     */
    minimize(): Promise<void> {
        return this.sendCommand("MIN").then(() => {});
    }

    /**
     * Maxmimize the iMotions software window if it is not running a study.
     */
    maximize(): Promise<void> {
        return this.sendCommand("MAX").then(() => {});
    }

    /**
     * Shut down the iMotions software if it is not running a study.
     */
    shutdown(): Promise<void> {
        return this.sendCommand("SHUTDOWN").then(() => {});
    }

    /**
     * Go to the next stimulus in the running study.
     */
    goToNextStimulus(): Promise<void> {
        return this.sendCommand("SLIDESHOWNEXT").then(() => {});
    }

    /**
     * Cancel the current study session.
     */
    cancelSession(): Promise<void> {
        return this.sendCommand("SLIDESHOWCANCEL").then(() => {});
    }

    /**
     * Get the current status of the iMotions software.
     */
    getStatus(): Promise<StatusResponse> {
        return this.sendCommand("STATUS", 2).then(response => {
            return {
                study: response[8],
                respondent: response[9],
                stimulus: response[10],
                isBusy: !!response[11],
                statusText: response[12],
                progressText: response[13]
            };
        });
    }

    /**
     * Start a study session.
     */
    startSession(
        studyName: string,
        respondentName: string,
        respondentVariables?: {[key: string]: string},
        uiOptions?: UiOptions
    ): Promise<void> {
        const args = [studyName, respondentName];

        if (respondentVariables) {
            const variables = Object.entries(respondentVariables)
                .map(([name, value]) => `${name}=${value}`)
                .join(" ");
            args.push(variables);
        }

        if (uiOptions) {
            if (!respondentVariables) {
                args.push("");
            }
            args.push(uiOptions);
        }

        return this.sendCommand("RUN", 3, args).then(() => {});
    }

    /**
     * Import a zip file containing a study into iMotions.
     */
    importStudy(path: string, name?: string, mode: ImportOptions = "Auto"): Promise<void> {
        return this.sendCommand("LOAD", 1, [path, sanitize(name), mode]).then(() => {});
    }

    close() {
        this.socket.end();
    }
}
