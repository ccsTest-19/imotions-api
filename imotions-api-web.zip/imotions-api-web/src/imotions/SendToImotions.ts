import {Socket} from "net";
import {convertTimestamp, openSocket, sanitize} from "./ApiUtils";

export const connectEventReceivingApi = async (port = 8089) => {
    try {
        return new SendToImotions(await openSocket(port));
    } catch (e) {
        throw new Error(
            `Unable to connect to iMotions software, please check that it is running and that the Event Receiving API is enabled on port ${port}`
        );
    }
};

/**
 * Send sensor data and markers to the iMotions software that will be inserted into the running study via the "Event Receiving API".
 * iMotions must be configured for the sensor data first by importing an XML file that defines them.
 */
export default class SendToImotions {
    private readonly socket: Socket;

    constructor(socket: Socket) {
        this.socket = socket;
    }

    private send(type: string, version: number, ...args: string[]) {
        const cmd = [type, `${version}`].concat(args).join(";") + "\r\n";
        this.socket.write(cmd);
    }

    /**
     * Send a marker for a single standalone event.
     */
    sendMarker(name: string, description = "", timestamp?: Date) {
        return this.send("M", 2, convertTimestamp(timestamp), "", sanitize(name), sanitize(description), "D", "");
    }

    /**
     * Send the start of a video scene.
     */
    sendVideoSceneStart(name: string, description = "", timestamp?: Date) {
        return this.send("M", 2, convertTimestamp(timestamp), "", sanitize(name), sanitize(description), "N", "V");
    }

    /**
     * Send the start of an image scene.
     * An image segment is visually identical for the duration (regardless of whether that is because it is an actual image, or a still scene in a video).
     */
    sendImageSceneStart(name: string, description = "", timestamp?: Date) {
        return this.send("M", 2, convertTimestamp(timestamp), "", sanitize(name), sanitize(description), "N", "I");
    }

    /**
     * Send the end of a previously started scene.
     */
    sendSceneEnd(name: string, timestamp?: Date) {
        return this.send("M", 2, convertTimestamp(timestamp), "", sanitize(name), "", "E", "");
    }

    /**
     * Send sensor data.
     * @param eventSourceId The sensor event source ID, i.e. the Id attribute of the EventSource tag.
     * @param sampleId The sensor sample ID, i.e. the Id attribute of the Sample tag.
     * @param data Data for the sample's fields, in the same order as they appear in the XML file.
     * @param timestamp
     * @param instance
     * @param version The data definition version, i.e. the Version attribute of the EventSource tag.
     */
    sendSensorData(
        eventSourceId: string,
        sampleId: string,
        data: any[],
        timestamp?: Date,
        instance = "",
        version?: number
    ) {
        const fields = [eventSourceId, version, instance, convertTimestamp(timestamp), "", sampleId]
            .concat(data)
            .map(sanitize);
        return this.send("E", 1, ...fields);
    }

    close() {
        this.socket.end();
    }
}
