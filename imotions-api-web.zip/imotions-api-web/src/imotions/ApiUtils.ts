import net, {Socket} from "net";
import {format} from "date-fns";

export const openSocket = (port: number): Promise<Socket> => {
    return new Promise((resolve, reject) => {
        const socket = net.createConnection({port: port}, () => {
            resolve(socket);
        });
        socket.once("error", reject);
    });
};

export const sanitize = (text: unknown) => {
    if (text === null || text === undefined) {
        return "";
    }
    if (typeof text !== "string") {
        return `${text}`;
    }
    return text.replace(/;/g, "_");
};

export const convertTimestamp = (ts: Date | number | undefined) => {
    if (ts === undefined) {
        return "";
    }
    if (ts instanceof Date) {
        return format(ts, "yyyyMMddHHmmssSSS");
    }
    return `${ts}`;
};
