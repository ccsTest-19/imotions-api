import https from "https";
import fs from "fs";
import path from "path";
import express from "express";
import bodyParser from "body-parser";
import {connectEventReceivingApi} from "./imotions/SendToImotions";

const start = async () => {
    const app = express();
    // Enable Express to parse the body of form requests.
    app.use(bodyParser.urlencoded({extended: true}));
    const sendToImotions = await connectEventReceivingApi();

    app.post("/marker", (req, res) => {
        sendToImotions.sendMarker(req.body.name, req.body.description, req.body.ts || new Date());
        console.log(`Sent marker '${req.body.name}' to iMotions.`);
        res.sendStatus(200);
    });

    const port = 8000;
    const server = https.createServer({
        ca: fs.readFileSync(path.join(process.env.LOCALAPPDATA!, "mkcert", "rootCA.pem")),
        cert: fs.readFileSync(path.resolve(__dirname, "..", "localhost+2.pem")),
        key: fs.readFileSync(path.resolve(__dirname, "..", "localhost+2-key.pem"))
    }, app).listen(port);
    console.log(`Server started on https://localhost:${port}.`);
};

start().catch(e => console.error(e));
