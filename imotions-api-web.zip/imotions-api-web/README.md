# iMotions API from website example
The iMotions event receiving API can be used to dynamically insert markers or create scenes depending on respondent behavior during a study.
However this uses sockets, which means that is is not possible to directly use the API from Javascript running inside a website.
This example illustrates how a web server running on the same computer as the iMotions software can be used as an intermediary to allow this.

The idea is then to run this server while the respondent is being tested, and modify the website they are visiting by adding some Javascript to e.g. 
send markers when the respondent does something interesting. It would also be possible to create scenes to split up the web stimulus if e.g. 
the website uses a Javascript framework that changes the contents of the page without changing the url.

This example uses Node.js and TypeScript for the server but it should be easy to adapt into other programming languages if required.

See the [iMotions API Programming Guide](https://help.imotions.com/hc/en-us/articles/203045581-iMotions-API-Programming-Guide) for more information about the API.

## HTTPS
Most websites today use the https protocol for secure data transfer, which means that this web server must also use https for them to communicate. To set this up:
1. Download [mkcert](https://github.com/FiloSottile/mkcert/releases) to the project folder.
2. Run `mkcert -install`.
3. Run `mkcert localhost 127.0.0.1 ::1`. This should produce two .pem files in the project folder.

## Running the example
1. Install dependencies with `npm install`.
2. Start the server with `npm run server`.
3. Start the iMotions software and make sure that the the event receiving API is enabled.
4. Create a study with "External Events API" enabled as a sensor, and add a web stimulus where the url points to the `example.html` file (e.g. `file://C:/Code/imotions-api-web/src/exmple.html`).
5. Create a respondent and start the study.
6. Click the "Send marker" button and notice how the "Incoming Events API" in iMotions receives the marker.
